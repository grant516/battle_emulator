#include "player.h"
#include <iostream>
#include <string>
#include "json.h"

using json = nlohmann::json;
using namespace std;

double debuffRatePlayer = 0.67;

Player::Player(json data) : name(""), hp(10), speed(10), attack(10), debuffAttack(1), debuffSpeed(1){
	/*string input;
	cout << "Player's name: ";
	getline(cin, name);
	cout << name <<"'s HP: ";
	cin >> input;
	hp = stod(input);
	cout << name <<"'s Attack: ";
	cin >> input;
	attack = stod(input);
	cout << name <<"'s Speed: ";
	cin >> input;
	speed = stod(input);*/

	name = data["name"];
	attack = data["attack"];
	speed = data["speed"];
	hp = data["hp"];
	maxHp = data["hp"];

	debuffAttack = 1;
	debuffSpeed = 1;
}

string Player::getName() {
	return name;
}
double Player::getHP() {
	return hp;
}
double Player::getSpeed() {
	return speed * debuffSpeed;
	}
double Player::getAttack() {
	double value = rand() % 100 + 1;
	if (value < 6.25) {
		return attack * 2;
		cout << name << " attacked, it was a Critical Hit!" << endl;
	}
	else {
		return attack * debuffAttack;
	}
	}
void Player::setDebuffSpeed() {
	debuffSpeed *= debuffRatePlayer;
	cout << name << "'s speed was lowered." << endl;
	}
void Player::setDebuffAttack() {
	debuffSpeed *= debuffRatePlayer;
	cout << name << "'s attack was lowered." << endl;
	}
void Player::changeHP(double attack) {
	if (attack < 0) {
		if ((hp - attack) > maxHp) {
			hp = maxHp;
		}
		else {
			hp -= attack;
			cout << name << " healed " << -attack << "HP!" << endl;
		}
	}
	else {
		hp -= attack;
		cout << name << " took damage!" << endl;
	}
	}